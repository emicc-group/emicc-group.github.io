---
# Display name
title: Sheng Weimin

# Username (this should match the folder name)
authors:
- shengweimin

# Is this the primary user of the site?
superuser: false

# Role/position
role: Logistics Scheduling

# Organizations/Affiliations
organizations:
- name: Zhejiang University of Technology, College of Mechanical Engineering
  url: ""

# Short bio (displayed in user profile at end of posts)
bio: 

# interests:
# - Logistics Scheduling
# - Algorithm Research

# education:
#  courses:
#  - course: BEng in Industrial Engineering
#    institution: Zhejiang University of Technology
#    year: 2023

# Social/Academic Networking
# For available icons, see: https://sourcethemes.com/academic/docs/page-builder/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
- icon: envelope
  icon_pack: fas
  link: 'mailto:1377456302@qq.com'
# - icon: twitter
#  icon_pack: fab
#  link: https://twitter.com/GeorgeCushen
# - icon: google-scholar
#  icon_pack: ai
#  link: https://scholar.google.com.tw/citations?user=LPhpYcwAAAAJ&hl=zh-TW&oi=ao 
- icon: gitee
  icon_pack: fab
# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ""

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
- Grad Students
# - Faculty
# - Researchers
# - Visitors
---

### **Biography**

I received my B.E. degree in Department of Industrial Engineering in June 2023 from Zhejiang University of Technology. Currently I am a first-year graduate student of College of Mechanical Engineering in Zhejiang University of Technology and a member of [EMICC Group](https://emicc-group.github.io). 

+ Supervisor: Prof. Yong Chen

+ Email: 1377456302@qq.com

### Educations


+ M.Eng. in Mechanical Engineering, Zhejiang Unviersity of Technology, 2023 - Present
+ B.E. in Industrial Engineering, Zhejiang University of Technology, 2019 - 2023

### Research Interests


+ Logistics Scheduling
+ Algorithm Reseach



### Awards & Honors

+ Zhejiang University of Technology Study Scholarship(2019-2021)

### Correspondence

+ Laboratory: Room D516, Mechanical Engineering Building, Zhejiang University of technology
+ Address: Weimin Sheng, Zhejiang University of Technology, Pingfeng Campus, 288 Liuhe Rd, Xihu District, Hangzhou 310023, China





